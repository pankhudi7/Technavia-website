import ThirdDiv  from "./thirddiv";
export default ThirdDiv;