import React from 'react';
import ReactDOM from 'react-dom';
import ApplicationCard from "D:/Users/pankh/Desktop/technavia_website/src/components/Application/ApplicationCard.js";

const Apps = () => {
  return (
    <div>
      <h1 align="left">Applications</h1>
      <div className="app-container">
        <ApplicationCard
          name="Robotic/Reciprocator painting"
          description="Robotic painting provides unexceptional quality and helps in achieving desired productivity with nearly nil rejection. 
          Technavia team has installed 300 plus painting robots so far in the various manufacturing sectors. Implementation of robotic system in a painting process reboots 
          the conventional method of painting and advances whole process with new technology. We also provide reciprocator system in painting with the various available 
          atomisers and also with disc applicator considering the profile of the component and its feeding method.
          We have developed reciprocator system for low budget project by optimizing it with any form of applicator."
          // imageUrl="url-to-app1-logo.png"
        />

        <ApplicationCard
          name="Painting Applicator"
          description="Applicator selection plays a key role in achieving the desired result by following the set conditions. 
          Technavia has used every form of applicator considering the requirement on particular component. 
          Starting from the conventional gun, air resisted gun, electrostatic gun, and electrostatic dual gun and Bell applicator."
        />

        <ApplicationCard
          name="Dozing equipment"
          description="We deliver dozing equipment like FCV (flow control valve), FGP (Flushable Gear Pump) and flow meter base system for 1K and 2K colours. 
          The dozing equipment are characterised by the level of precision required in the quantity of the paint sprayed by the applicator."
     
        />

        <ApplicationCard
          name="Colour changing system"
          description="In the condition of more than one number of colour we equip our system with Colour 
          changing valve, which expedite the colour changing process and diminish the wastage of solvent while cleaning the line."
         
        />

        <ApplicationCard
          name="Paint circulation system"
          description="We integrate painting applicators and robots with the best suited paint circulation system available. With the technology and experience 
          accumulated from the period of robotic painting projects, we can build more sophisticated paint circulation system by providing constant amount feed device 
          for 1K, 2K and 3K component with accurate mixing ratio and consistent performance."
         
        />

        <ApplicationCard
        name="Pigging system"
        description="We provide full-fledged solution with pigging system. The use of pig systems in painting facilities optimises economy – via short paint changing times and recovery of material. 
        The pigging system returns valuable paint and hardener to the supply units in optimal purity and remove the excess pipe content from the piping systems with minimal loss, quickly and without residue."
        
        />

        <ApplicationCard
        name="Electrical & Pneumatic control systems"
        description="Technavia has in house facility for making electrical control panel, equipping with the desired PLC as per the customer requirement. 
        In our off line testing facility we primarily emphasize on the logics developed for the particular system and only after the dry trials we allow for dispatching the system to customer.
        We build customized pneumatic control panel for automatic painting system fulfilling the requirement of the painting line. We follow international standard by equipping the panel with reputed make items."
        
        />

        <ApplicationCard
        name="SCADA System"
        description="Technavia has its SCADA(Supervisory Control and Data Acquisition) which is a control system architecture that uses computers, networked data communication and 
        graphical user interfaces for high-level process supervisory management. SCADA uses PLC for logically controlling the process of devices used in the system and to demonstrate on the screen.
        SCADA enhances the productivity by making it easy to monitor the various parameters in the painting process. The SCADA system provided by us is as per the industry 4.0 standard."
        imageUrl=""
        />

        <ApplicationCard
        name="Sealing & Dispensing Application"
        description="We provide turnkey solution for sealing application in which Technavia product line has seventh axis slider which is mainly used for providing more accessibility to robot while applying under body sealing and PVC coating in car body or truck cabin.

        Technavia has provided automation solution for the below mentioned various sealing & dispensing process.
        <ul>
        <li>PVC Seam Sealing: Sealing job to fill the gap with PVC paint</li>
        <li>LASD (Liquid Applied Sound Deadener): Sealing job to apply soundproof materials to reduce noise by removing the vibrations caused by driving under body Sealing</li>
        <li>UBS (Under Body Sealing): Sealing job to apply the sealer of synthetic rubber as the main component by robot to the gap between steel sheets</li>
        <li>UBC (Under Body Coat-Deadener): Sealing job to apply dark grey coloured coating material of PVC resin to floor surface of automobile under body.</li>
        <li>RPP (Rocker Panel Protector): Sealing job to apply paint with urethane component in order to prevent automobile under body including the bottom part of fender and skirt panel from cracks caused by stones.</li>"
        imageUrl=""
        />

        <ApplicationCard
        name="Handling Application"
        description="Technavia provide robust solution for automated machine tending application either with robotic arm or customised system for fulfilling the requirement of transferring component. As handling is a vast subject differing by nature of process, types of component and the manufacturing application.
        We provide gantry and rail system to accommodate maximum numbers of machines in a single line with a single robot or with the customized handling method. Technavia emphasizes to provide new technology by equipping the system with latest gripping solution in order to deliver an efficient system.
        Technavia follows modern day automatic handling system with vision system for the fixed programming routines to carry out the production on the various variants. Instead of reprogramming each new position for the robot system the system takes over real-time control of the robot and carries out the required steps autonomously. Technavia interfaces the robotic system with vision system for making it a complete unit for achieving the mentioned requirement of modern day manufacturing technique.
        Considering the current scenario in industry where men and robots are required to work together. This requirement of industry became the key reason of developing the “COLABORATIVE “system between Man and robot. Technavia has garnered rich experience in installing handling/sealing system with the ‘COBOT’.
        Technavia is undertaking the following handling application projects
        <ul>
        <li>Machine tending</li>
        <li>Alloy wheel handling system</li>
        <li>Transferring system</li>
        <li>Press handling</li>
        <li>Press bending</li>
        <li>Palletizing</li>
        <li>Gantry and rail system</li>"
        imageUrl=""
        />

      </div>
    </div>
  );
};

ReactDOM.render(<Apps />, document.getElementById('root'));

export default Apps;

