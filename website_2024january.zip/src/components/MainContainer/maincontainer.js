import Firstdiv from "../Home";
import Seconddiv from "../AboutUs";
import ThirdDiv from "../Products";
import NewDiv from "D:/Users/pankh/Desktop/technavia_website/src/components/ApplicationContent/Apps.js"
import FourthDiv from "../TeamMembers";
import Fifthdiv from "../ServiceSection";
import Sixthdiv from "../Careers";
import Eighthdiv from "D:/Users/pankh/Desktop/technavia_website/src/components/Testimonials/TestimonialsSection.js"
import Sevendiv from "../ContactUs";


const mainContainer = ({ refs }) => {
  return (
    <>
      <div>
        <Firstdiv ref={refs}/>
        <Seconddiv ref={refs.aboutUsRef}/>
        <ThirdDiv ref={refs.productsRef}/>
        <FourthDiv ref={refs.teamMembersRef}/>
        <NewDiv ref={refs.applicationsRef}/>
        <Fifthdiv ref={refs.serviceSectionRef}/>
        <Sixthdiv ref={refs.careersPageRef}/>
        <Eighthdiv ref={refs.testimonialsSectionRef}/>
        <Sevendiv ref={refs.contactusRef}/>
      </div>
    </>
  );
};
export default mainContainer;


