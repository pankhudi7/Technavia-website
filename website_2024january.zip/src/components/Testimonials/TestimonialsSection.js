import React,{useEffect} from 'react';
import TestimonialCard from "D:/Users/pankh/Desktop/technavia_website/src/components/Testimonials/TestimonialCard.js"; 
import './TestimonialsSection.css';
import Aos from "aos";

const TestimonialsSection = () => {
  useEffect(()=>{
    Aos.init({duration:2000});
  },[])
  return (
    <section className="testimonials-section">
      <div className="testimonials-container">
        <h2 className="section-title" data-aos="zoom-in">Client Testimonials</h2>
        <div className="testimonials-grid">
          <TestimonialCard
            name="Hero Motocorp"
            content="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
          />
          <TestimonialCard
          name="Bajaj Auto"
          content="lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut  " />          
          <TestimonialCard
          name="Plustech Systems & Solutions Pvt Ltd"
          content="lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut  " />
          
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;