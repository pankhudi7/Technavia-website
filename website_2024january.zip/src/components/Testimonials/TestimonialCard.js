import React,{useEffect} from 'react';
import "D:/Users/pankh/Desktop/technavia_website/src/components/Testimonials/TestimonialsSection.css";
import Aos from "aos";

const TestimonialCard = ({ name, content,logo }) => {
  useEffect(()=>{
    Aos.init({duration:3000});
  },[])
  return (
    <div className="testimonial-card" data-aos="zoom-in">
      <blockquote className="testimonial-content">{content}</blockquote>
      <div className="testimonial-author">
        <p className="author-name">{name}</p>
        <img src='{logopic}' alt='logo of company' className='author-logo' >{logo}</img>
      </div>
    </div>
  );
};

export default TestimonialCard;
