import FlippingCard from "./flippingCard"
export default FlippingCard;