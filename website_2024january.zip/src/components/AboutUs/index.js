import SecondDiv from "./seconddiv"
export default SecondDiv;