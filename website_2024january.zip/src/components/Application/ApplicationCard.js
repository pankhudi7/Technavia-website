import React,{useEffect} from 'react';
import PropTypes from 'prop-types';
import './ApplicationCard.css'; 
import Aos from 'aos';

const ApplicationCard = ({ name, description, imageUrl }) => {
  useEffect(()=>{
    Aos.init({duration:2000});
  },[])
  return (
    <div className="application-card" data-aos="zoom-in">
      <img src={imageUrl} alt={`applications of ${name}`} className="app-name" />
      <h2 className="app-name">{name}</h2>
      <p className="app-description">{description}</p>
    </div>
  );
};

ApplicationCard.propTypes = {
  name: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  imageUrl: PropTypes.string.isRequired,
};

export default ApplicationCard;
