import "./App.css";
import AppHeader from "./components/AppHeader";
import MainContainer from "./components/MainContainer";
import React, { useRef } from "react";
import { HashRouter } from "react-router-dom";
// import Numberdiv from "./components/numberAnimation";
// import TeamMembers from "./components/TeamMembers";
// import Testimonials from "./components/Testimonials";

function App() {
  const homeRef = useRef(null);
  const aboutUsRef = useRef(null);
  const productsRef = useRef(null);
  const applicationRef = useRef(null);
  const teamMemberRef = useRef(null);
  const serviceRef = useRef(null);
  const industryRef = useRef(null);
  const newsCenterRef = useRef(null);
  const carrerRef = useRef(null);
  const contactUsRef = useRef(null);
  const testimonialsRef = useRef(null);
  const careersPageRef = useRef(null);
  const serviceSectionRef = useRef(null);
  const testimonialsSectionRef = useRef(null);
  const applicationsRef = useRef(null);
  return (
    <div ref={homeRef} className="App">
      <HashRouter>
        <AppHeader
          refs={{
            aboutUsRef,
            productsRef,
            applicationRef,
            serviceRef,
            industryRef,
            newsCenterRef,
            carrerRef,
            contactUsRef,
            homeRef,
            teamMemberRef,
            testimonialsRef,
            careersPageRef,
            serviceSectionRef,
            testimonialsSectionRef,
            applicationsRef
          }}
        />
        <MainContainer refs={{
            aboutUsRef,
            productsRef,
            applicationRef,
            serviceRef,
            industryRef,
            newsCenterRef,
            carrerRef,
            contactUsRef,
            homeRef,
            teamMemberRef,
            testimonialsRef,
            careersPageRef,
            serviceSectionRef,
            testimonialsSectionRef,
            applicationsRef
          }} />
        {/* <Numberdiv/> */}
      </HashRouter>
    </div>
  );
}

export default App;
